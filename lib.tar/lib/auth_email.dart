import 'package:basicapp/state/auth2_controller.dart';

import 'auth_shared.dart';

Future<UserCredential> signupWithEmail(String email, String password) async {
  try {
    UserCredential userCredential = await auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    return userCredential;
  } on FirebaseAuthException catch (e) {
    final message = switch (e.code) {
      == 'weak-password' => 'The password provided is too weak.',
      == 'email-already-in-use' =>
        'The account[ ${e.email} ] already exists for that email.',
      _ => '',
    };

    throw UnauthorizedException2('Cannot create an account: $message');
  }
}

Future<UserCredential> signinWithEmail(String email, String password) async {
  return auth.signInWithEmailAndPassword(email: email, password: password);
}
