library auth_shared;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_sign_in/google_sign_in.dart';

export 'package:firebase_auth/firebase_auth.dart';
export 'package:firebase_core/firebase_core.dart';

part './auth_google.dart';

late final FirebaseApp app;
late final FirebaseAuth auth;

const List<String> scopes = <String>[
  'email',
  'https://www.googleapis.com/auth/contacts.readonly',
];
