import 'package:mylib/mylib.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../auth_email.dart';
import '../entities/auth2.dart';

part 'auth2_controller.g.dart';

/// A mock of an Authenticated User
final _dummyUser = Auth2.signedIn(
  id: -1,
  displayName: '으라차차',
  email: 'gcback@gmail.com',
  token: 'some-updated-secret-auth-token',
);

////////
abstract class AuthIface {
  Future<void> login(String email, String password);
  Future<void> logout();
  Future<void> signup(String email, String password);
}

@riverpod
class Auth2Controller extends _$Auth2Controller implements AuthIface {
  late SharedPreferences _sharedPreferences;
  static const _sharedPrefsKey = 'token';
  get instance => _sharedPreferences;

  @override
  Future<Auth2> build() async {
    _sharedPreferences = await SharedPreferences.getInstance();

    _persistenceRefreshLogic();

    return _loginRecoveryAttempt();
  }

  void _persistenceRefreshLogic() {
    ref.listenSelf((_, next) {
      if (next.isLoading) return;
      if (next.hasError) {
        _sharedPreferences.remove(_sharedPrefsKey);
        return;
      }

      next.requireValue.map<void>(
        signedIn2: (signedIn) =>
            _sharedPreferences.setString(_sharedPrefsKey, signedIn.token),
        signedOut2: (signedOut) {
          _sharedPreferences.remove(_sharedPrefsKey);
        },
      );
    });
  }

  Future<Auth2> _loginRecoveryAttempt() {
    try {
      final savedToken = _sharedPreferences.getString(_sharedPrefsKey);
      if (savedToken == null) {
        throw const UnauthorizedException2('No auth token found');
      }

      return _loginWithToken(savedToken);
    } catch (_, __) {
      _sharedPreferences.remove(_sharedPrefsKey).ignore();
      return Future.value(Auth2.signedOut());
    }
  }

  Future<Auth2> _loginWithToken(String token) async {
    final logInAttempt = await Future.delayed(
      networkRoundTripTime,
      () => true, // edit this if you wanna play around
    );

    if (logInAttempt) return _dummyUser;

    throw const UnauthorizedException2('401 Unauthorized or something');
  }

  ///
  ///
  @override
  Future<void> login(String email, String password) async {
    try {
      final userCredential = await signinWithEmail(email, password);

      if (userCredential.user case var user?) {
        state = AsyncData(
          Auth2.signedIn(
            id: user.hashCode,
            email: user.email ?? '',
            token: (await user.getIdToken()) ?? '',
            displayName: user.displayName ?? '',
          ),
        );
      }
    } catch (e) {
      print('cannot create an User > email:$email, password:$password');
    }
  }

  @override
  Future<void> logout() async {
    await Future<void>.delayed(networkRoundTripTime);

    state = AsyncData(Auth2.signedOut());
  }

  @override
  Future<void> signup(String email, String password) async {
    try {
      final userCredential = await signupWithEmail(email, password);

      if (userCredential.user case var user?) {
        state = AsyncData(
          Auth2.signedIn(
            id: user.hashCode,
            email: user.email ?? '',
            token: (await user.getIdToken()) ?? '',
            displayName: user.displayName ?? '',
          ),
        );
      }
    } catch (e) {
      print('cannot create an User > email:$email, password:$password');
    }
  }
}

/// Simple mock of a 401 exception
class UnauthorizedException2 implements Exception {
  const UnauthorizedException2(this.message);
  final String message;
}

/// Mock of the duration of a network request
final networkRoundTripTime = 2.secs;
