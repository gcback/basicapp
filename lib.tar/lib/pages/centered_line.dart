import 'package:mylib/mylib.dart';

class CenteredLine extends StatelessWidget {
  const CenteredLine({
    super.key,
    required this.size,
    this.indent,
    this.endIndent,
    this.borderSide,
    this.padding,
    this.child,
  });

  final Size size;
  final double? indent;
  final double? endIndent;
  final BorderSide? borderSide;
  final EdgeInsets? padding;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return SizedBox.fromSize(
      size: size,
      child: CustomPaint(
        painter: CenteredPainter(
          indent: indent ?? 0.0,
          endIndent: endIndent ?? 0.0,
          padding: padding ?? EdgeInsets.zero,
          borderSide: borderSide ?? const BorderSide(width: 0.5),
        ),
        child: Padding(
          padding: padding ?? EdgeInsets.zero,
          child: child,
        ),
      ),
    );
  }
}

class CenteredPainter extends CustomPainter {
  const CenteredPainter({
    required this.indent,
    required this.endIndent,
    required this.padding,
    required this.borderSide,
  });

  final double indent, endIndent;
  final EdgeInsets padding;
  final BorderSide borderSide;

  static final painter = Paint()..style = PaintingStyle.stroke;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final innerRect = Offset(indent, 0.0) &
        Size(size.width - (indent + endIndent), size.height);

    final halfRect = Alignment.bottomCenter
        .inscribe(Size(innerRect.width, innerRect.height / 2), innerRect);

    canvas.drawRect(
        innerRect,
        painter
          ..color = borderSide.color
          ..strokeWidth = borderSide.width);

    canvas.drawLine(
        halfRect.topLeft,
        halfRect.topRight,
        painter
          ..color = Colors.red
          ..strokeWidth = borderSide.width);
  }

  @override
  bool shouldRepaint(covariant CenteredPainter oldDelegate) => true;
}
