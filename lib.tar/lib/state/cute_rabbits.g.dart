// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cute_rabbits.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$cuteRabbitsHash() => r'a18ba49859da8dd597c7b05b4bb69303c2458cdb';

/// See also [cuteRabbits].
@ProviderFor(cuteRabbits)
final cuteRabbitsProvider =
    AutoDisposeFutureProvider<List<(IconData, String)>>.internal(
  cuteRabbits,
  name: r'cuteRabbitsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$cuteRabbitsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CuteRabbitsRef = AutoDisposeFutureProviderRef<List<(IconData, String)>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
