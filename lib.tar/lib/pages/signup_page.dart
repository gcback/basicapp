import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mylib/mylib.dart';

import '../state/auth_controller.dart';
import 'auth_field_types.dart';
import 'signup_view.dart';

class SignUpPage extends HookConsumerWidget {
  const SignUpPage({super.key});

  static const title = 'SignUp Page';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final controllers = useFormFieldControllers(fields: EditFormFields.signup);
    final authValue = useState<AuthInput>(controllers.empty);

    return Scaffold(
      appBar: AppBar(
        title: const Text(title),
      ),
      body: Center(
        child: Padding(
          padding: 12.0.horiInsets,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 1),
              Expanded(
                flex: 2,
                child: Form(
                  key: formKey,
                  child:
                      SignUpView(controllers: controllers, title: 'SignUpView'),
                ),
              ),
              const Gap(24.0),
              Text(authValue.value.toString()),
              Expanded(
                flex: 1,
                child: Center(
                  child: OutlinedButton(
                    onPressed: () {
                      if (!formKey.currentState!.validate()) return;

                      ref.read(authControllerProvider.notifier).signup(
                            controllers.authValue.email,
                            controllers.authValue.password,
                          );
                      // signupWithEmail
                    },
                    child: const Text('Press'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
