// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth2_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$auth2ControllerHash() => r'bc0bc6f131e5adf4261bccc1f50d1925e96c786e';

/// See also [Auth2Controller].
@ProviderFor(Auth2Controller)
final auth2ControllerProvider =
    AutoDisposeAsyncNotifierProvider<Auth2Controller, Auth2>.internal(
  Auth2Controller.new,
  name: r'auth2ControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$auth2ControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Auth2Controller = AutoDisposeAsyncNotifier<Auth2>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
