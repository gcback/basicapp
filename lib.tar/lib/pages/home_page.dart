import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../auth/logout_button.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  static const title = 'Home Page';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(title),
        actions: const [LogoutButton()],
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("There's nothing much you can do, here"),
          ],
        ),
      ),
    );
  }
}
