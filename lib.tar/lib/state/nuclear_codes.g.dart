// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nuclear_codes.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$nuclearCodesHash() => r'eae3401e73bd3cdf5cbb2013444957e1426100ad';

/// See also [nuclearCodes].
@ProviderFor(nuclearCodes)
final nuclearCodesProvider =
    AutoDisposeFutureProvider<List<(IconData, String)>>.internal(
  nuclearCodes,
  name: r'nuclearCodesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$nuclearCodesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef NuclearCodesRef
    = AutoDisposeFutureProviderRef<List<(IconData, String)>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
