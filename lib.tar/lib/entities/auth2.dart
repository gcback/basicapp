sealed class Auth2 {
  factory Auth2.signedIn({
    required int id,
    required String displayName,
    required String email,
    required String token,
  }) =>
      SignedIn2(id: id, displayName: displayName, email: email, token: token);
  factory Auth2.signedOut() => SignedOut2();

  bool get isAuth;

  TResult map<TResult extends Object?>({
    required TResult Function(SignedIn2 value) signedIn2,
    required TResult Function(SignedOut2 value) signedOut2,
  });
}

class SignedIn2 implements Auth2 {
  final int id;
  final String displayName;
  final String email;
  final String token;

  SignedIn2(
      {required this.id,
      required this.displayName,
      required this.email,
      required this.token});

  @override
  bool get isAuth => true;

  @override
  TResult map<TResult extends Object?>({
    required TResult Function(SignedIn2 value) signedIn2,
    required TResult Function(SignedOut2 value) signedOut2,
  }) =>
      signedIn2(this);
}

class SignedOut2 implements Auth2 {
  @override
  bool get isAuth => false;

  @override
  TResult map<TResult extends Object?>({
    required TResult Function(SignedIn2 value) signedIn2,
    required TResult Function(SignedOut2 value) signedOut2,
  }) =>
      signedOut2(this);
}
