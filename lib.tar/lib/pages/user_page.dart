import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mylib/mylib.dart';

import '../state/cute_rabbits.dart';
import '../auth/logout_button.dart';
import '../auth/my_sliver_list.dart';
import '../auth/user_title.dart';

class UserPage extends ConsumerWidget {
  const UserPage({super.key});

  static const title = 'User\'s Page';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rabbits = ref.watch(cuteRabbitsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text(title),
        actions: const [LogoutButton()],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "Looks like you've got enough permissions to... pick up some rabbits 😍",
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Flexible(
                  child: CustomScrollView(
                    slivers: [
                      const SliverToBoxAdapter(child: UserTitle()),
                      MySliverList(elements: rabbits),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
